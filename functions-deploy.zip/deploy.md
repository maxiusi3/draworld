# Cloud Functions 部署指南

## 环境变量配置

在部署 Cloud Functions 之前，需要配置通义万相 API 密钥：

```bash
# 方法1: 使用 Firebase CLI 配置
firebase functions:config:set tongyi.api_key="your-dashscope-api-key"

# 方法2: 在 Google Cloud Console 中设置环境变量
# 1. 访问 Google Cloud Console
# 2. 进入 Cloud Functions
# 3. 选择函数并编辑
# 4. 在环境变量中添加：
#    DASHSCOPE_API_KEY = your-dashscope-api-key
```

## 部署命令

```bash
# 部署所有 Functions
firebase deploy --only functions

# 部署特定函数
firebase deploy --only functions:createVideoTask
firebase deploy --only functions:getUserVideoTasks
firebase deploy --only functions:uploadImage
```

## 验证部署

部署完成后，可以在 Firebase Console 中验证：

1. 访问 [Firebase Console](https://console.firebase.google.com)
2. 选择项目 `draworld-6898f`
3. 进入 "Functions" 页面
4. 确认以下函数已部署：
   - `createVideoTask`
   - `getUserVideoTasks`
   - `uploadImage`

## 测试 API

可以使用以下方式测试 API：

```javascript
// 在浏览器控制台中测试
const { getFunctions, httpsCallable } = await import('firebase/functions');
const functions = getFunctions();
const createVideoTask = httpsCallable(functions, 'createVideoTask');

const result = await createVideoTask({
  imageUrl: 'https://example.com/image.jpg',
  prompt: '测试视频生成',
  musicStyle: 'Joyful',
  aspectRatio: '16:9'
});

console.log('任务创建成功:', result.data);
```

## 常见问题

### 1. API 密钥未配置
错误：`DASHSCOPE_API_KEY environment variable is required`
解决：按照上述方法配置 API 密钥

### 2. CORS 错误
错误：`Access to fetch at '...' from origin '...' has been blocked by CORS policy`
解决：确保 CORS 配置正确，已在代码中添加

### 3. 权限错误
错误：`permission-denied`
解决：确保用户已登录，检查 Firebase Auth 配置
